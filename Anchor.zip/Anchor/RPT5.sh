#!/bin/sh
###calling profile script
. achr_mig.profile
echo connection string is $CONN_STRING
##
sqlplus /nolog<<!EOF
set echo on
conn ${CONN_STRING}
set echo on
set define off
spool run_proc_reportall.log

select sysdate from dual;
var v_dummy varchar2
---var v_dummy2 varchar2

Insert Into SCBT_T_ANCH_SCRIPT_TRACK values ('RPT5.sh',sysdate,null,'In Progress','RPT');
COMMIT;

EXEC SCBK_P_REPORT_MIG_LMT_OTP.SCBP_P_RPT_OTP('SCB', 'SG', 'SP','${1}','${2}');


Update SCBT_T_ANCH_SCRIPT_TRACK SET END_TIME = sysdate ,STATUS = 'Completed'  where SCRIPT_NAME = 'RPT5.sh';
COMMIT

select sysdate from dual;
spool off
exit;
!EOF
