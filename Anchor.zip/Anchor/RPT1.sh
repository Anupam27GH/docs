#!/bin/sh
###calling profile script
. achr_mig.profile
echo connection string is $CONN_STRING
##   
sqlplus /nolog<<!EOF
set echo on
conn ${CONN_STRING}
set echo on
set define off
spool run_procrpt1.log

select sysdate from dual;
var v_dummy varchar2

Insert Into SCBT_T_ANCH_SCRIPT_TRACK values ('RPT1.sh',sysdate,null,'In Progress','RPT');
COMMIT;

-- SCBT_T_RPT_BASE

DECLARE
        
        P_CATEGORY            VARCHAR2 (100 BYTE) :='RPTTRANS';
        P_TABLE_NAME          VARCHAR2 (100 BYTE);
        P_COUNT_BEFORE_MIG    NUMBER (20);
        P_COUNT_AFTER_MIG     NUMBER (20);
        P_START_TIME          DATE;
        P_END_TIME            DATE;
        P_STATUS              VARCHAR2 (10 BYTE);
        P_REMARKS             VARCHAR2 (500 BYTE);
        P_OPERATION           VARCHAR2 (10 BYTE) := 'PARALLEL';

        l_sql_stmt VARCHAR2(1000);
        l_try NUMBER;
        l_status NUMBER;

BEGIN

        P_TABLE_NAME := 'SCBT_T_RPT_BASE';
        P_START_TIME := SYSDATE;

        BEGIN
        				     
        SELECT /*+ PARALLEL(rbase) */ COUNT (1) 
          INTO P_COUNT_BEFORE_MIG
          FROM SCBT_T_RPT_BASE rbase
         WHERE rbase.bank_group_code = 'SCB'
           AND rbase.cty_code        = 'SG'
           and rbase.business_date   between '${1}' and '${2}'
           and rbase.position_marker = 'DALY'
           AND EXISTS(select 1 
                        from scbt_t_anch_cust anch
                       where anch.party_id = rbase.party_id
                         and anch.sys_ind  = 'OTP'); 					     

        EXCEPTION WHEN OTHERS THEN
      	          P_COUNT_BEFORE_MIG := 0;
        END;

        -- Create the TASK
        DBMS_PARALLEL_EXECUTE.CREATE_TASK ('basetask');

        -- Chunk the table by ROWID
        DBMS_PARALLEL_EXECUTE.CREATE_CHUNKS_BY_ROWID('basetask', 'OPS\$GTPS01', 'SCBT_T_RPT_BASE', true, 50000);

        -- Execute the DML in parallel
        l_sql_stmt := 'update /*+ ROWID (dda) */ SCBT_T_RPT_BASE rbase
                          SET rbase.CTY_CODE = '||'''SP''' || '  
                            , rbase.tbu_code = GET_ANCHOR_TBU_CODE(' || '''SCB''' || ' , ' || '''SG''' || ' , rbase.tbu_code)
      	                WHERE rowid BETWEEN :start_id AND :end_id
                          AND rbase.BANK_GROUP_CODE = ' || '''SCB''' || '
                          AND rbase.CTY_CODE = ' || '''SG''' || '
                          and rbase.business_date   between ' || '''${1}''' || ' and ' || '''${2}''' || '
	                  and rbase.position_marker = ' || '''DALY'''  || '
                          AND EXISTS (SELECT 1 FROM SCBT_T_ANCH_CUST PM
      	                               WHERE PM.bank_group_code = '|| '''SCB''' ||
      	                               ' AND PM.cty_code = ' ||'''SG''' ||
      	                               ' AND PM.party_id = rbase.party_id)';

        DBMS_PARALLEL_EXECUTE.RUN_TASK('basetask', l_sql_stmt, DBMS_SQL.NATIVE, parallel_level => 10);

        -- If there is an error, RESUME it for at most 2 times.
        L_try := 0;
        L_status := DBMS_PARALLEL_EXECUTE.TASK_STATUS('basetask');
        WHILE(l_try < 2 and L_status != DBMS_PARALLEL_EXECUTE.FINISHED)
        LOOP
            L_try := l_try + 1;
            DBMS_PARALLEL_EXECUTE.RESUME_TASK('basetask');
            L_status := DBMS_PARALLEL_EXECUTE.TASK_STATUS('basetask');
        END LOOP;

        -- Done with processing; drop the task
        DBMS_PARALLEL_EXECUTE.DROP_TASK('basetask');

        P_STATUS   := 'SUCCESS';
        P_END_TIME := SYSDATE;
        P_REMARKS  := '';

        BEGIN
        					 
	SELECT /*+ PARALLEL(rbase) */ COUNT (1) 
	  INTO P_COUNT_AFTER_MIG
	  FROM SCBT_T_RPT_BASE rbase
	 WHERE rbase.bank_group_code = 'SCB'
	   AND rbase.cty_code        = 'SP'
	   and rbase.business_date   between '${1}' and '${2}'
	   and rbase.position_marker = 'DALY'
	   AND EXISTS(select 1 
			from scbt_t_anch_cust anch
		       where anch.party_id = rbase.party_id
		 	 and anch.sys_ind  = 'OTP');

        EXCEPTION WHEN OTHERS THEN
    	            P_COUNT_AFTER_MIG := 0;
        END;

       scbk_p_report_mig_lmt_otp.SCBP_P_INS_RPT_MIG_STAT(P_CATEGORY,P_TABLE_NAME,P_COUNT_BEFORE_MIG,P_COUNT_AFTER_MIG,P_START_TIME,P_END_TIME,P_STATUS,P_REMARKS,P_OPERATION);
       COMMIT;
       
       EXCEPTION WHEN OTHERS THEN
       	 DBMS_PARALLEL_EXECUTE.DROP_TASK('basetask');
       
       	 P_END_TIME := SYSDATE;
       	 scbk_p_report_mig_lmt_otp.SCBP_P_INS_RPT_MIG_STAT(P_CATEGORY,P_TABLE_NAME,P_COUNT_BEFORE_MIG,P_COUNT_AFTER_MIG,P_START_TIME,P_END_TIME,P_STATUS,P_REMARKS,P_OPERATION);
         COMMIT;     
END;
/

Update SCBT_T_ANCH_SCRIPT_TRACK SET END_TIME = sysdate ,STATUS = 'Completed'  where SCRIPT_NAME = 'RPT1.sh';
COMMIT;

select sysdate from dual;
spool off
exit;
!EOF

nohup sh /home/otpsupp/Conversion/RPT/RPT1.sh 01-APR-2013 30-JUN-2013 > /dev/null &
nohup sh /home/otpsupp/Conversion/RPT/RPT2.sh 01-APR-2013 30-JUN-2013 > /dev/null &
nohup sh /home/otpsupp/Conversion/RPT/RPT3.sh 01-APR-2013 30-JUN-2013 > /dev/null &
nohup sh /home/otpsupp/Conversion/RPT/RPT4.sh 01-APR-2013 30-JUN-2013 > /dev/null &
nohup sh /home/otpsupp/Conversion/RPT/RPT5.sh 01-APR-2013 30-JUN-2013 > /dev/null &
nohup sh /home/otpsupp/Conversion/RPT/RPT7.sh > /dev/null &
