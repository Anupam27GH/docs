#!/bin/sh
###calling profile script
. achr_mig.profile
echo connection string is $CONN_STRING
##
sqlplus /nolog<<!EOF
set echo on
conn ${CONN_STRING}
set echo on
set define off
spool run_procrpt2.log

select sysdate from dual;
var v_dummy varchar2

Insert Into SCBT_T_ANCH_SCRIPT_TRACK values ('RPT2.sh',sysdate,null,'In Progress','RPT');
COMMIT;

-- SCBT_T_RPT_ACC_ENTRY

DECLARE
        
   P_CATEGORY            VARCHAR2 (100 BYTE) :='RPTTRANS';
   P_TABLE_NAME          VARCHAR2 (100 BYTE);
   P_COUNT_BEFORE_MIG    NUMBER (20);
   P_COUNT_AFTER_MIG     NUMBER (20);
   P_START_TIME          DATE;
   P_END_TIME            DATE;
   P_STATUS              VARCHAR2 (10 BYTE);
   P_REMARKS             VARCHAR2 (500 BYTE);
   P_OPERATION           VARCHAR2 (10 BYTE) := 'PARALLEL';

        l_sql_stmt VARCHAR2(1000);
        l_try NUMBER;
        l_status NUMBER;

BEGIN

        P_TABLE_NAME := 'SCBT_T_RPT_ACC_ENTRY';
        P_START_TIME := SYSDATE;

        BEGIN
        
          SELECT /*+ PARALLEL(ae) */ COUNT (1) 
          INTO P_COUNT_BEFORE_MIG
          FROM SCBT_T_RPT_ACC_ENTRY ae
          WHERE ae.bank_group_code = 'SCB'
          AND ae.cty_code          = 'SG'
          and ae.business_date   between '${1}' and '${2}'
          and ae.position_marker = 'DALY'
          AND EXISTS(select 1 
                     from scbt_t_anch_cust anch
                     where anch.party_id = ae.cust_id
                     and anch.sys_ind  = 'OTP');                 


        EXCEPTION WHEN OTHERS THEN
      	          P_COUNT_BEFORE_MIG := 0;
        END;

        -- Create the TASK
        DBMS_PARALLEL_EXECUTE.CREATE_TASK ('aetask');

        -- Chunk the table by ROWID
        DBMS_PARALLEL_EXECUTE.CREATE_CHUNKS_BY_ROWID('aetask', 'OPS\$GTPS01', 'SCBT_T_RPT_ACC_ENTRY', true, 50000);

        -- Execute the DML in parallel
        l_sql_stmt := 'update /*+ ROWID (dda) */ SCBT_T_RPT_ACC_ENTRY ae
                          SET ae.CTY_CODE = '||'''SP''' || '  
                            , ae.tbu_code = GET_ANCHOR_TBU_CODE(' || '''SCB''' || ' , ' || '''SG''' || ' , ae.tbu_code)
      	                WHERE rowid BETWEEN :start_id AND :end_id
                          AND ae.BANK_GROUP_CODE = ' || '''SCB''' || '
                          AND ae.CTY_CODE        = ' || '''SG''' || '
		          and ae.business_date   between ' || '''${1}''' || ' and ' || '''${2}''' || '
		          and ae.position_marker = ' || '''DALY'''  || '
                          AND EXISTS (SELECT 1 FROM SCBT_T_ANCH_CUST PM
      	                               WHERE PM.bank_group_code = '|| '''SCB''' || '
      	                                 AND PM.cty_code = ' ||'''SG''' || '
      	                                 AND PM.party_id = ae.cust_id)';

        DBMS_PARALLEL_EXECUTE.RUN_TASK('aetask', l_sql_stmt, DBMS_SQL.NATIVE, parallel_level => 10);

        -- If there is an error, RESUME it for at most 2 times.
        L_try := 0;
        L_status := DBMS_PARALLEL_EXECUTE.TASK_STATUS('aetask');
        WHILE(l_try < 2 and L_status != DBMS_PARALLEL_EXECUTE.FINISHED)
        LOOP
          BEGIN 
           L_try := l_try + 1;
            DBMS_PARALLEL_EXECUTE.RESUME_TASK('aetask');
            L_status := DBMS_PARALLEL_EXECUTE.TASK_STATUS('aetask');
          EXCEPTION WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('ERROR' || 'ERROR - 0');                
          END; 
        END LOOP;

        -- Done with processing; drop the task
        DBMS_PARALLEL_EXECUTE.DROP_TASK('aetask');

        P_STATUS := 'SUCCESS';
        P_END_TIME := SYSDATE;
        P_REMARKS := '';


        BEGIN
          SELECT /*+ PARALLEL(ae) */ COUNT (1) 
          INTO P_COUNT_AFTER_MIG    
          from SCBT_T_RPT_ACC_ENTRY ae
          where ae.bank_group_code = 'SCB'
          and ae.cty_code          = 'SP'
          and ae.business_date   between '${1}' and '${2}'
          and ae.position_marker   = 'DALY'
          and EXISTS(select 1
                     from scbt_t_anch_cust anch
                     where anch.party_id = ae.cust_id
                     and anch.sys_ind    = 'OTP');         
        EXCEPTION WHEN OTHERS THEN
  	          P_COUNT_AFTER_MIG := 0;
        END;

       scbk_p_report_mig_lmt_otp.SCBP_P_INS_RPT_MIG_STAT(P_CATEGORY,P_TABLE_NAME,P_COUNT_BEFORE_MIG,P_COUNT_AFTER_MIG,P_START_TIME,P_END_TIME,P_STATUS,P_REMARKS,P_OPERATION);
       COMMIT;
       
       EXCEPTION WHEN OTHERS THEN
         DBMS_PARALLEL_EXECUTE.DROP_TASK('aetask');
          
	 P_END_TIME := SYSDATE;
	 scbk_p_report_mig_lmt_otp.SCBP_P_INS_RPT_MIG_STAT(P_CATEGORY,P_TABLE_NAME,P_COUNT_BEFORE_MIG,P_COUNT_AFTER_MIG,P_START_TIME,P_END_TIME,P_STATUS,P_REMARKS,P_OPERATION);
         COMMIT;

END;
/

--SCBT_T_RPT_SB_INV_OTH

DECLARE
                
        P_CATEGORY            VARCHAR2 (100 BYTE) :='RPTTRANS';
        P_TABLE_NAME          VARCHAR2 (100 BYTE);
        P_COUNT_BEFORE_MIG    NUMBER (20);
        P_COUNT_AFTER_MIG     NUMBER (20);
        P_START_TIME          DATE;
        P_END_TIME            DATE;
        P_STATUS              VARCHAR2 (10 BYTE);
        P_REMARKS             VARCHAR2 (500 BYTE);
        P_OPERATION           VARCHAR2 (10 BYTE) := 'PARALLEL';

        l_sql_stmt VARCHAR2(1000);
        l_try NUMBER;
        l_status NUMBER;

BEGIN

        P_TABLE_NAME := 'SCBT_T_RPT_SB_INV_OTH';
        P_START_TIME := SYSDATE;

        BEGIN
        
        SELECT /*+ PARALLEL(sio) */ COUNT (1) 
	  INTO P_COUNT_BEFORE_MIG
	  FROM SCBT_T_RPT_SB_INV_OTH sio
	 WHERE sio.bank_group_code = 'SCB'
	   AND sio.cty_code        = 'SG'
	   and sio.business_date   between '${1}' and '${2}'
	   and sio.position_marker = 'DALY'
	   AND EXISTS(select 1 
			from scbt_t_anch_cust anch
		       where anch.party_id = sio.cust_id
                         and anch.sys_ind  = 'OTP');
        
        EXCEPTION WHEN OTHERS THEN
      	          P_COUNT_BEFORE_MIG := 0;
        END;

        -- Create the TASK
        DBMS_PARALLEL_EXECUTE.CREATE_TASK ('siotask');

        -- Chunk the table by ROWID
        DBMS_PARALLEL_EXECUTE.CREATE_CHUNKS_BY_ROWID('siotask', 'OPS\$GTPS01', 'SCBT_T_RPT_SB_INV_OTH', true, 50000);

        -- Execute the DML in parallel
        l_sql_stmt := 'update /*+ ROWID (dda) */ SCBT_T_RPT_SB_INV_OTH sio
                          SET sio.CTY_CODE = ' || '''SP''' || '
                            , sio.tbu_code = GET_ANCHOR_TBU_CODE(' || '''SCB''' || ' , ' || '''SG''' || ' , sio.tbu_code)
      	                WHERE rowid BETWEEN :start_id AND :end_id
                          AND sio.BANK_GROUP_CODE = ' || '''SCB''' || '
                          AND sio.CTY_CODE = ' || '''SG''' || '
                          and sio.business_date   between ' || '''${1}''' || ' and ' || '''${2}''' || '
			  and sio.position_marker = ' || '''DALY'''  || '
                          AND EXISTS (SELECT 1 FROM SCBT_T_ANCH_CUST PM
      	                               WHERE PM.bank_group_code = '|| '''SCB''' ||
      	                               ' AND PM.cty_code = ' ||'''SG''' ||
      	                               ' AND PM.party_id = sio.cust_id)';

        DBMS_PARALLEL_EXECUTE.RUN_TASK('siotask', l_sql_stmt, DBMS_SQL.NATIVE, parallel_level => 10);

        -- If there is an error, RESUME it for at most 2 times.
        L_try := 0;
        L_status := DBMS_PARALLEL_EXECUTE.TASK_STATUS('siotask');
        WHILE(l_try < 2 and L_status != DBMS_PARALLEL_EXECUTE.FINISHED)
        LOOP
            L_try := l_try + 1;
            DBMS_PARALLEL_EXECUTE.RESUME_TASK('siotask');
            L_status := DBMS_PARALLEL_EXECUTE.TASK_STATUS('siotask');
        END LOOP;

        -- Done with processing; drop the task
        DBMS_PARALLEL_EXECUTE.DROP_TASK('siotask');

        P_STATUS   := 'SUCCESS';
        P_END_TIME := SYSDATE;
        P_REMARKS  := '';

        BEGIN
        
        SELECT /*+ PARALLEL(sio) */ COUNT (1) 
	  INTO P_COUNT_AFTER_MIG
	  FROM SCBT_T_RPT_SB_INV_OTH sio
	 WHERE sio.bank_group_code = 'SCB'
	   AND sio.cty_code        = 'SP'
	   and sio.business_date   between '${1}' and '${2}'
	   and sio.position_marker = 'DALY'
	   AND EXISTS(select 1 
			from scbt_t_anch_cust anch
		       where anch.party_id = sio.cust_id
                         and anch.sys_ind  = 'OTP');
        
        EXCEPTION WHEN OTHERS THEN
    	            P_COUNT_AFTER_MIG := 0;
        END;

       scbk_p_report_mig_lmt_otp.SCBP_P_INS_RPT_MIG_STAT(P_CATEGORY,P_TABLE_NAME,P_COUNT_BEFORE_MIG,P_COUNT_AFTER_MIG,P_START_TIME,P_END_TIME,P_STATUS,P_REMARKS,P_OPERATION);
       COMMIT;
       
       EXCEPTION WHEN OTHERS THEN
       	 DBMS_PARALLEL_EXECUTE.DROP_TASK('siotask');
       
       	 P_END_TIME := SYSDATE;
       	 scbk_p_report_mig_lmt_otp.SCBP_P_INS_RPT_MIG_STAT(P_CATEGORY,P_TABLE_NAME,P_COUNT_BEFORE_MIG,P_COUNT_AFTER_MIG,P_START_TIME,P_END_TIME,P_STATUS,P_REMARKS,P_OPERATION);
	 COMMIT;
END;
/

-- SCBT_T_RPT_DOC_FIN_BAL

DECLARE
        P_CATEGORY            VARCHAR2 (100 BYTE) :='RPTTRANS';
        P_TABLE_NAME          VARCHAR2 (100 BYTE);
        P_COUNT_BEFORE_MIG    NUMBER (20);
        P_COUNT_AFTER_MIG     NUMBER (20);
        P_START_TIME          DATE;
        P_END_TIME            DATE;
        P_STATUS              VARCHAR2 (10 BYTE);
        P_REMARKS             VARCHAR2 (500 BYTE);
        P_OPERATION           VARCHAR2 (10 BYTE) := 'PARALLEL';

        l_sql_stmt VARCHAR2(1000);
        l_try NUMBER;
        l_status NUMBER;

BEGIN

        P_TABLE_NAME := 'SCBT_T_RPT_DOC_FIN_BAL';
        P_START_TIME := SYSDATE;

        BEGIN
          SELECT /*+ PARALLEL(dfb) */ COUNT (1) 
          INTO P_COUNT_BEFORE_MIG
			     FROM SCBT_T_RPT_DOC_FIN_BAL dfb
			    WHERE dfb.bank_group_code = 'SCB'
			      AND dfb.cty_code        = 'SG'
			      and dfb.business_date   between '${1}' and '${2}' 
			      and dfb.position_marker = 'DALY'
			      AND EXISTS(select 1
					             from scbt_t_anch_cust anch
					             where anch.party_id = dfb.cust_id
				               and anch.sys_ind  = 'OTP');

        EXCEPTION WHEN OTHERS THEN
      	  P_COUNT_BEFORE_MIG := 0;
        END;

        -- Create the TASK
        DBMS_PARALLEL_EXECUTE.CREATE_TASK ('dfbtask');

        -- Chunk the table by ROWID
        DBMS_PARALLEL_EXECUTE.CREATE_CHUNKS_BY_ROWID('dfbtask', 'OPS\$GTPS01', 'SCBT_T_RPT_DOC_FIN_BAL', true, 50000);

        -- Execute the DML in parallel
        l_sql_stmt := 'update /*+ ROWID (dda) */ SCBT_T_RPT_DOC_FIN_BAL dfb
                          SET dfb.CTY_CODE = '||'''SP''' || ' 
                            , dfb.tbu_code = GET_ANCHOR_TBU_CODE(' || '''SCB''' || ' , ' || '''SG''' || ' , dfb.tbu_code)
      	                WHERE rowid BETWEEN :start_id AND :end_id
                          AND dfb.BANK_GROUP_CODE = ' || '''SCB''' || '
                          AND dfb.CTY_CODE = ' || '''SG''' || '
		          and dfb.business_date   between ' || '''${1}''' || ' and ' || '''${2}''' || '
		          and dfb.position_marker = ' || '''DALY'''  || '
		          AND EXISTS (SELECT 1 
                          FROM SCBT_T_ANCH_CUST PM
				                  WHERE PM.bank_group_code = '|| '''SCB''' ||
				                ' AND PM.cty_code = ' ||'''SG''' ||
				                ' AND PM.party_id = dfb.cust_id)';

        DBMS_PARALLEL_EXECUTE.RUN_TASK('dfbtask', l_sql_stmt, DBMS_SQL.NATIVE, parallel_level => 10);

        -- If there is an error, RESUME it for at most 2 times.
        L_try := 0;
        L_status := DBMS_PARALLEL_EXECUTE.TASK_STATUS('dfbtask');
        WHILE(l_try < 2 and L_status != DBMS_PARALLEL_EXECUTE.FINISHED)
        LOOP
            L_try := l_try + 1;
            DBMS_PARALLEL_EXECUTE.RESUME_TASK('dfbtask');
            L_status := DBMS_PARALLEL_EXECUTE.TASK_STATUS('dfbtask');
        END LOOP;

        -- Done with processing; drop the task
        DBMS_PARALLEL_EXECUTE.DROP_TASK('dfbtask');

        P_STATUS   := 'SUCCESS';
        P_END_TIME := SYSDATE;
        P_REMARKS  := '';

        BEGIN
          SELECT /*+ PARALLEL(dfb) */ COUNT (1) 
          INTO P_COUNT_AFTER_MIG
			    FROM SCBT_T_RPT_DOC_FIN_BAL dfb
			    WHERE dfb.bank_group_code = 'SCB'
			      AND dfb.cty_code        = 'SP'
			      and dfb.business_date   between  '${1}' and '${2}' 
			      and dfb.position_marker = 'DALY'
			      AND EXISTS(select 1
					             from scbt_t_anch_cust anch
					             where anch.party_id = dfb.cust_id
				               and anch.sys_ind  = 'OTP');
        
        EXCEPTION WHEN OTHERS THEN
    	            P_COUNT_AFTER_MIG := 0;
        END;

       scbk_p_report_mig_lmt_otp.SCBP_P_INS_RPT_MIG_STAT(P_CATEGORY,P_TABLE_NAME,P_COUNT_BEFORE_MIG,P_COUNT_AFTER_MIG,P_START_TIME,P_END_TIME,P_STATUS,P_REMARKS,P_OPERATION);
       COMMIT;
       
       EXCEPTION WHEN OTHERS THEN
       	 DBMS_PARALLEL_EXECUTE.DROP_TASK('dfbtask');
       
       	 P_END_TIME := SYSDATE;
       	 scbk_p_report_mig_lmt_otp.SCBP_P_INS_RPT_MIG_STAT(P_CATEGORY,P_TABLE_NAME,P_COUNT_BEFORE_MIG,P_COUNT_AFTER_MIG,P_START_TIME,P_END_TIME,P_STATUS,P_REMARKS,P_OPERATION);
	 COMMIT;
END;
/

Update SCBT_T_ANCH_SCRIPT_TRACK SET END_TIME = sysdate ,STATUS = 'Completed'  where SCRIPT_NAME = 'RPT2.sh';
COMMIT;

select sysdate from dual;
spool off
exit;
!EOF